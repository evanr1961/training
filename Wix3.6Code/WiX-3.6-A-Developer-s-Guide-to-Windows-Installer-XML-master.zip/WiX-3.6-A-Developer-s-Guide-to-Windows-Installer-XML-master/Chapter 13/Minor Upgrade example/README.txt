This example demonstrates buildin a patch file to update an existing product.

To run this example:

1. Run Build.bat to build the OriginalProduct.msi and Patch.msp files
2. Install OriginalProduct.msi (in Output folder)
3. Install Patch.msp (in Output folder)
4. Check the InstallMe.txt file in Program Files\Awesome Software to see that it was updated
5. Uninstall OldInstaller when finished