This example demonstrates using a progress bar.

To run this example:

1. Compile the solution in Visual Studio
2. Run the installer to see various messages displayed over a progress bar. These messages
   comes from a C# custom action.