This example demonstrates using a Billboard control. It will display several billboards.

To run this example:

1. Compile the solution in Visual Studio
2. Run the installer and see the billboards