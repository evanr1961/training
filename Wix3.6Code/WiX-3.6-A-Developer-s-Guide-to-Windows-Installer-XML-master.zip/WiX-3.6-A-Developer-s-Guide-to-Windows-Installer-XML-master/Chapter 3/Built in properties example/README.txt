This example demonstrates how to set the Add/Remove Programs properties that are built into WiX.

To run the example:

1. Compile the project in Visual Studio
2. Check Add/Remove programs to see the effect of the properties defined in Product.wxs

Icon from: http://www.iconshock.com/icon_sets/55-free-user-icons-pixel-by-pixel-icons/