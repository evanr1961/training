This example demonstrates using DirectorySearch to see if a folder exists. In this case, it checks
for the Notepad++ folder under Program Files.

To run this example:

1. Compile the project in Visual Studio
2. Run the installer and it will display a messagebox with either:
   A. That Notepad++ is not installed
   B. The path to the Notepad++ folder