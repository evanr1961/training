This example demonstrates reading the Registry. It finds the version of DirectX that is installed and displays
it in the message box.

To run this example:

1. Compile the project in Visual Studio
2. Run the installer to see a messagebox that shows the installed version of DirectX