This example shows that it's possible to build a WiX project without using Visual Studio.

To run this example:

1. Double click the CMD file to build.
2. Double click the resulting MSI file to launch the installer