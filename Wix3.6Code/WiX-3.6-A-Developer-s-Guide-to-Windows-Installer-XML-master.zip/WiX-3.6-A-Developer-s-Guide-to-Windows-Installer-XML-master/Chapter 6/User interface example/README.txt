This example demonstrates adding a user interface to a WiX installer. The UI shows an intro screen that has
an "Install" button. When the Install button is clicked a Progress dialog is shown.

To run this example:

1. Compile the project in Visual Studio
2. Run the installer to see the user interface