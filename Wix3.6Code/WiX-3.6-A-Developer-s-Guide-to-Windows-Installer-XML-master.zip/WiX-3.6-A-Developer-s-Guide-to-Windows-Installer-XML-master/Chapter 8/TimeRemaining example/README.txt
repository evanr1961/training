This example demonstrates displaying time remaining over the progress bar.

To run this example:

1. Compile the solution in Visual Studio
2. Run the installer and see the time remaining messages over the progress bar