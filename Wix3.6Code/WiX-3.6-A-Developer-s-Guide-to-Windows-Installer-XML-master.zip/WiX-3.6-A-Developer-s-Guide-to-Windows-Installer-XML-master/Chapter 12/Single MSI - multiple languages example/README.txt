This example demonstrates merging several MSIs into a single MSI that will display a different language depending on the user's settings.

To run this example:

1. Run the BuildMSI batch file (you may need to fix its directory references)
2. Launch the MultiLanguage.msi that you get
3. To see it in Spanish, change your language to Spanish 

	Control Panel -> Regional and Language Options -> Regional Options -> Spanish/Spain

4. Relaunch installer
5. To see German, change language to Germany/Germany