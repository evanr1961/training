This example demonstrates a custom action that uses VBScript written inline in the WiX markup. It will display
a messagebox using vbscript during the install.

To run this example:

1. Compile the project in Visual Studio
2. Run the installer to see the messagebox pop up. This was done with vbscript.