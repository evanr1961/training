This example demonstrates setting the path of an installed directory using a custom action. The install folder is
changed from being under Program Files to being under %ProgramData%.

To run this example:

1. Compile the project in Visual Studio
2. Run the installer and check that the installed files are in the %ProgramData% directory and not 
   Program Files