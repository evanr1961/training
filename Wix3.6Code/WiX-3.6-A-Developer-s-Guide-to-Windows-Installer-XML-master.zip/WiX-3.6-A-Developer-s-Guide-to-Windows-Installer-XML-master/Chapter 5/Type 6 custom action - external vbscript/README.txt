This example demonstrates calling a custom action that is defined in an external VBScript file.

To run this example:

1. Compile the project in Visual Studio
2. Run the installer to see a messagebox pop up that was defined by the VBScript file