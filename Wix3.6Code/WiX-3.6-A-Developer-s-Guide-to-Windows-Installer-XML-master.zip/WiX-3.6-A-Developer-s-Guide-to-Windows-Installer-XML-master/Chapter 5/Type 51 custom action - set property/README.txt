This example demonstrates setting a property with a custom action. It will display a messagebox during the
install showing that the property has been changed from its original value "123" to the new value "456".

To run this example:

1. Compile the project in Visual Studio
2. Run the installer to see a messagebox about the changed property