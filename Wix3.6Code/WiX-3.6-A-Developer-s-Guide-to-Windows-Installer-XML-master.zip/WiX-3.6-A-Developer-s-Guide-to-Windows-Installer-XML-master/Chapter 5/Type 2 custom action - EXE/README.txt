This example demonstrates using an executable file to define a custom action. The .exe will display a messagebox
with the value of a WiX property that was defined by the WiX markup.

To run this example:

1. Compile the solution in Visual Studio
2. Run the installer to see the messagebox pop up