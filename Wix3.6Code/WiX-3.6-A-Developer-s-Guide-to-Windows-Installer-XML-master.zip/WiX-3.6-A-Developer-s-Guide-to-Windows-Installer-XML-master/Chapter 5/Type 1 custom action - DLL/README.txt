This example demonstrates using C# code to create a custom action. The C# method displays a messagebox with the value
of a WiX property.

To run this example:

1. Compile the solution in Visual Studio
2. Run the installer to see that a messagebox is displayed with the value of a WiX property that
   was set in the WiX markup