This example demonstrates a basic WiX Setup project. It installs a text file to a folder under Program Files and
adds a shortcut to the Start Menu.

To run the example:

1. Compile the project in Visual Studio
2. Run the installer and check the Start Menu, Program Files and Add/Remove Programs to see what was installed

