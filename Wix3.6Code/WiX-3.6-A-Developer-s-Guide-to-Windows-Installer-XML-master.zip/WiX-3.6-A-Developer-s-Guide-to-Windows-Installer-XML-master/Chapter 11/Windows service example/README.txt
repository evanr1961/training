This example demonstrates how to create a simple Windows service and install it with WiX.

To run this example:

1. Compile the solution in Visual Studio
2. Install the resulting MSI file
3. Check the service management console (Run -> services.msc) to see the "Test Service"
4. Uninstall afterwards