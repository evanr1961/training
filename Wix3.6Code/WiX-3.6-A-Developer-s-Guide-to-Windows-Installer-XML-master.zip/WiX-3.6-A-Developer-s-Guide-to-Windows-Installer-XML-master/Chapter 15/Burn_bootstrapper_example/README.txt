This example demonstrates a simple bootstrapper using Burn. It installs two MSIs.

To run this example:

1. Compile the Visual Studio solution
2. Run the resulting EXE file to install the two MSIs