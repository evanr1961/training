This example demonstrates setting file permissions on an installed file.

To run this example:

1. Compile the project in Visual Studio
2. Run the MSI and check that a file called InstallMe.txt was installed. 
3. Right click on the file and view the Secrurity tab to see that permissions were added
   for a user called WixTestUser