This example demonstrates using Heat.exe to create a WXS file. Heat will scan the "Testing_Heat"
directory and create Component and File elements for the text files it finds.

To run this example:

1. Run the "run_heat.cmd" script to see a WXS file created that uses all of the default Heat settings
2. Run the "run_heat2.cmd" script to see a WXS file that customizes the flags passed to Heat to get 
   better formatted output