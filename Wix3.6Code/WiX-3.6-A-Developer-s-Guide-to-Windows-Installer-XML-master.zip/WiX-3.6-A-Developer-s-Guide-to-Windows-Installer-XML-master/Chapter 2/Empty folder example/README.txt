This example demonstrates installing an empty folder.

To run this example:

1. Compile the project in Visual Studio
2. Run the MSI and see that an empty folder was installed under the new software's Program Files folder