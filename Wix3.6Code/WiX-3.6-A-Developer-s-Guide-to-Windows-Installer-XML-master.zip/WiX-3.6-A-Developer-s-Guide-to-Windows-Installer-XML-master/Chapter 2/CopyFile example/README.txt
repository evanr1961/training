This example demonstrates installing a text file and then copying that file to another folder.

To run this example:

1. Compile the project in Visual Studio
2. Run the MSI and see that an "OriginalFiles" folder contains the original text file
   and that a "CopiedFiles" folder contains the copied file 