This example demonstrates reading the Registry.

To run this example:

1. Build the project in Visual Studio
2. Double click the resulting MSI file to install
3. See that it shows a message saying what value it found in the Registry
4. Uninstall afterwards